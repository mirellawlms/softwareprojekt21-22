package GUI;

import java.awt.*;

public class GameTopPanel extends Panel {
    public GameTopPanel() {
    }

    @Override
    public void paint(Graphics graphics) {

    }
    public void drawScore(Graphics graphics) {

    }
    public void drawNextPiece(Graphics graphics) {

    }

}
