package GUI;

import java.awt.*;

public class PieceLabel {
    private int pnr;
    private int px;
    private int py;

    public PieceLabel() {
    }

    public void paint(Graphics graphics) {

    }

    public void checkState(int pnr) {

    }

}
