package GUI;

import java.awt.*;

public class MainFrame extends Frame {
    int x;
    int y;
    int width;
    int heigth;
    private GamePanel GamePanel;
    private CreatorStartPanel CreatorStartPanel;
    private StartPanel StartPanel;
    private HauptmenuePanel HauptmenuePanel;
    private EditorPanel EditorPanel;
    private EinstellungPanel EinstellungPanel;
    private LeaderboardPanel LeaderboardPanel;


}
