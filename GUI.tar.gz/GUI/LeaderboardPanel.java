package GUI;

import java.awt.*;

public class LeaderboardPanel extends Panel {
    public LeaderboardPanel() {
    }

    @Override
    public void paint(Graphics graphics) {
        super.paint(graphics);
    }
}
