package GUI;

import java.awt.*;

public class GameGridPanel extends Panel {
    public GameGridPanel() {
    }
    @Override
    public void paint(Graphics graphics) {

    }
    public void getGrid() {

    }
    public void drawPiece(piece) {

    }
    public void eraseLine(int) {

    }
}
