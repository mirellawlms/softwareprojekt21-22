package GUI;

import java.awt.*;

public class BlockBuildPanel extends Panel {
    public BlockBuildPanel() {
    }

    @Override
    public void paint(Graphics graphics) {

    }
}
