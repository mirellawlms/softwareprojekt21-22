package GUI;

import java.awt.*;

public class GameOptionPanel extends Panel {
    public GameOptionPanel() {
    }

    @Override
    public void paint(Graphics graphics) {

    }
}
