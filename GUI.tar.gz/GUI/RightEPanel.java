package GUI;

import java.awt.*;

public class RightEPanel extends Panel {
    public RightEPanel() {
    }

    @Override
    public void paint(Graphics graphics) {

    }
}
