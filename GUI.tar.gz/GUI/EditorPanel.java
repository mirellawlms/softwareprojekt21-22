package GUI;

import java.awt.*;

public class EditorPanel extends Panel {
    private BlockBuildPanel BlockBuildPanel;
    private EditAreaPanel EditAreaPanel;
    private RightEPanel RightEPanel;
    private LeftEPanel LeftEPanel;

    public EditorPanel() {
    }

    @Override
    public void paint(Graphics graphics) {

    }
}
