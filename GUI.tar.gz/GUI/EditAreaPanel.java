package GUI;

import java.awt.*;

public class EditAreaPanel extends Panel {
    public EditAreaPanel() {
    }

    @Override
    public void paint(Graphics graphics) {

    }
}
