package GUI;

import java.awt.*;

public class GameLeaderBoard {
    public GameLeaderBoard() {
    }
    public void paint(Graphics graphics) {
        /*ist das die gleiche Paint methode wie bei den panel klassen?
        soll GLB auch eine subklasse von etwas sein?
         */
    }
}
