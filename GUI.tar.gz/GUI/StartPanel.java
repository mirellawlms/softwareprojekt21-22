package GUI;

import java.awt.*;

public class StartPanel extends Panel {
    public StartPanel() {
    }

    @Override
    public void paint(Graphics graphics) {
    }
}
