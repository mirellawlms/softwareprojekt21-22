package GUI;

import java.awt.*;

public class EinstellungPanel extends Panel {
    public EinstellungPanel() {
    }

    @Override
    public void paint(Graphics graphics) {
        super.paint(graphics);
    }
}
