package GUI;

import java.awt.*;

public class CreatorStartPanel extends Panel {
    public CreatorStartPanel() {
    }
    @Override
    public void paint(Graphics graphics) {
    }
}
