package GUI;

import java.awt.*;

public class GamePanel extends Panel {
    private GameLeaderBoard GameLeaderBoard;
    private GameGridPanel GameGridPanel;
    private GameOptionPanel GameOptionPanel;
    private GameTopPanel GameTopPanel;

    public GamePanel() {
    }

    @Override
    public void paint(Graphics graphics) {

    }
}
