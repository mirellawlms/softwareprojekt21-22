package GUI;

import java.awt.*;

public class LeftEPanel extends Panel {
    public LeftEPanel() {
    }

    @Override
    public void paint(Graphics graphics) {
        super.paint(graphics);
    }
}
