package GUI;

import java.awt.*;

public class HauptmenuePanel extends Panel {
    public HauptmenuePanel() {
    }

    @Override
    public void paint(Graphics graphics) {

    }
}
